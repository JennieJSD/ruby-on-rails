class CreatePorducts < ActiveRecord::Migration[7.1]
  def change
    create_table :porducts do |t|
      t.string :tittle
      t.text :description
      t.decimal :price

      t.timestamps
    end
  end
end
