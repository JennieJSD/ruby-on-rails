require "application_system_test_case"

class PorductsTest < ApplicationSystemTestCase
  setup do
    @porduct = porducts(:one)
  end

  test "visiting the index" do
    visit porducts_url
    assert_selector "h1", text: "Porducts"
  end

  test "should create porduct" do
    visit porducts_url
    click_on "New porduct"

    fill_in "Description", with: @porduct.description
    fill_in "Price", with: @porduct.price
    fill_in "Tittle", with: @porduct.tittle
    click_on "Create Porduct"

    assert_text "Porduct was successfully created"
    click_on "Back"
  end

  test "should update Porduct" do
    visit porduct_url(@porduct)
    click_on "Edit this porduct", match: :first

    fill_in "Description", with: @porduct.description
    fill_in "Price", with: @porduct.price
    fill_in "Tittle", with: @porduct.tittle
    click_on "Update Porduct"

    assert_text "Porduct was successfully updated"
    click_on "Back"
  end

  test "should destroy Porduct" do
    visit porduct_url(@porduct)
    click_on "Destroy this porduct", match: :first

    assert_text "Porduct was successfully destroyed"
  end
end
