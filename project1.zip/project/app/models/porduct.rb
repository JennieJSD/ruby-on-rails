class Porduct < ApplicationRecord
end
