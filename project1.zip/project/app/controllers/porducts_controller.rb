class PorductsController < ApplicationController
  before_action :set_porduct, only: %i[ show edit update destroy ]

  # GET /porducts or /porducts.json
  def index
    @porducts = Porduct.all
  end

  # GET /porducts/1 or /porducts/1.json
  def show
  end

  # GET /porducts/new
  def new
    @porduct = Porduct.new
  end

  # GET /porducts/1/edit
  def edit
  end

  # POST /porducts or /porducts.json
  def create
    @porduct = Porduct.new(porduct_params)

    respond_to do |format|
      if @porduct.save
        format.html { redirect_to porduct_url(@porduct), notice: "Porduct was successfully created." }
        format.json { render :show, status: :created, location: @porduct }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @porduct.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /porducts/1 or /porducts/1.json
  def update
    respond_to do |format|
      if @porduct.update(porduct_params)
        format.html { redirect_to porduct_url(@porduct), notice: "Porduct was successfully updated." }
        format.json { render :show, status: :ok, location: @porduct }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @porduct.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /porducts/1 or /porducts/1.json
  def destroy
    @porduct.destroy!

    respond_to do |format|
      format.html { redirect_to porducts_url, notice: "Porduct was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_porduct
      @porduct = Porduct.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def porduct_params
      params.require(:porduct).permit(:tittle, :description, :price)
    end
end
