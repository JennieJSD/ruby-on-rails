Rails.application.routes.draw do

  resources :porducts
  get 'home/index'
  get 'home/about'
  get 'home/contact'
  get 'home/product'
  root "home#index"
end
